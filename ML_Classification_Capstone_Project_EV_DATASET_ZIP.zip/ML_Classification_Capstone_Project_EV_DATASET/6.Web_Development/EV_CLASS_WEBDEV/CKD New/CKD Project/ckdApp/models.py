from django.db import models

# Create your models here.
class ckdModel(models.Model):

    Charging_Duration_minutes=models.FloatField()
    Initial_Battery_Level=models.FloatField()
    Battery_Capacity_kWh=models.FloatField()
    Maximum_Range_km=models.FloatField()
    Charging_Station_ID=models.FloatField()
