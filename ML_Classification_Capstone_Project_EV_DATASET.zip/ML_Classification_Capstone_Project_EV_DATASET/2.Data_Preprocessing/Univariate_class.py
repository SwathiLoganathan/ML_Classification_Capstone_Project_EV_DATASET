import pandas as pd
import numpy as np

class Univariate:

    @staticmethod
    def QuanQual(dataset):
        Quan = []
        Qual = []
        for columnName in dataset.columns:
            if dataset[columnName].dtypes == "O":
                Qual.append(columnName)
            else:
                Quan.append(columnName)
        return Quan, Qual

    @staticmethod
    def Descriptive(dataset, quan):
        descriptive = pd.DataFrame(index=["Mean", "Median", "Mode", "Q1:25%", "Q2:50%",
                                          "Q3:75%", "99%", "Q4:100%", "IQR", "1.5rule", "Lesser", "Greater",
                                          "Min", "Max", "kurtosis", "skew", "Var", "Std"], columns=quan)
        for columnName in quan:
            descriptive[columnName]["Mean"] = dataset[columnName].mean()
            descriptive[columnName]["Median"] = dataset[columnName].median()
            descriptive[columnName]["Mode"] = dataset[columnName].mode()[0]
            descriptive[columnName]["Q1:25%"] = dataset.describe()[columnName]["25%"]
            descriptive[columnName]["Q2:50%"] = dataset.describe()[columnName]["50%"]
            descriptive[columnName]["Q3:75%"] = dataset.describe()[columnName]["75%"]
            descriptive[columnName]["99%"] = np.percentile(dataset[columnName], 99)
            descriptive[columnName]["Q4:100%"] = dataset.describe()[columnName]["max"]
            descriptive[columnName]["IQR"] = descriptive[columnName]["Q3:75%"] - descriptive[columnName]["Q1:25%"]
            descriptive[columnName]["1.5rule"] = 1.5 * descriptive[columnName]["IQR"]
            descriptive[columnName]["Lesser"] = descriptive[columnName]["Q1:25%"] - descriptive[columnName]["1.5rule"]
            descriptive[columnName]["Greater"] = descriptive[columnName]["Q3:75%"] + descriptive[columnName]["1.5rule"]
            descriptive[columnName]["Min"] = dataset[columnName].min()
            descriptive[columnName]["Max"] = dataset[columnName].max()
            descriptive[columnName]["kurtosis"] = dataset[columnName].kurtosis()
            descriptive[columnName]["skew"] = dataset[columnName].skew()
            descriptive[columnName]["Var"] = dataset[columnName].var()
            descriptive[columnName]["Std"] = dataset[columnName].std()
        return descriptive

    @staticmethod
    def FindingOutlier(Quan, descriptive):
        Lesser = []
        Greater = []
        for ColumnName in Quan:
            if descriptive[ColumnName]["Min"] < descriptive[ColumnName]["Lesser"]:
                Lesser.append(ColumnName)
            if descriptive[ColumnName]["Max"] > descriptive[ColumnName]["Greater"]:
                Greater.append(ColumnName)
        return Lesser, Greater

    @staticmethod
    def Handle_outliers(dataset, descriptive, Quan, Lesser, Greater):
        #Lesser, Greater = Finding_outliers(descriptive, Quan)
        for ColumnName in Lesser:
            dataset.loc[dataset[ColumnName] < descriptive[ColumnName]["Lesser"], ColumnName] = descriptive[ColumnName]["Lesser"]
        for ColumnName in Greater:
            dataset.loc[dataset[ColumnName] > descriptive[ColumnName]["Greater"], ColumnName] = descriptive[ColumnName]["Greater"]
        return dataset

    @staticmethod
    def FreqTable(ColumnName, dataset):
        FreqTable = pd.DataFrame(columns=["Unique_Values", "Frequency", "Relative_Frequency", "Cummulative_Frequency or cumsum"])
        FreqTable["Unique_Values"] = dataset[ColumnName].value_counts().index
        FreqTable["Frequency"] = dataset[ColumnName].value_counts().values
        total_count = len(dataset[ColumnName])
        FreqTable["Relative_Frequency"] = FreqTable["Frequency"] / total_count
        FreqTable["Cummulative_Frequency or cumsum"] = FreqTable["Relative_Frequency"].cumsum()
        return FreqTable
        
    def get_pdf_probability(dataset, startrange, endrange):
        from matplotlib import pyplot
        from scipy.stats import norm
        import seaborn as sns
    
        ax = sns.distplot(dataset, kde=True, kde_kws={'color': 'blue'}, color='Green')
        pyplot.axvline(startrange, color='Red')
        pyplot.axvline(endrange, color='Red')
        sample = dataset
        sample_mean = sample.mean()
        sample_std = sample.std()
        print('Mean=%.3f, Standard Deviation=%.3f' % (sample_mean, sample_std))
        dist = norm(sample_mean, sample_std)
        values = []
        for value in range(startrange, endrange):
            values.append(value)
        probabilities = []
        for value in values:
            probabilities.append(dist.pdf(value))
        prob = sum(probabilities)
        print("The area between range({}, {}): {}".format(startrange, endrange, prob))
        return prob

    def stdNDgraph(dataset):
    
        import seaborn as sns
        from scipy.stats import zscore
        df = pd.DataFrame(dataset)
        
        # Calculate the Z-scores for each column
        z_scores_df = df.apply(zscore)
        sns.distplot(z_scores_df,kde=True)
        
        #Display the result
        print("Original DataFrame:")
        print(df)
        print("\nZ-scores DataFrame:")
        print(z_scores_df)
    


    
