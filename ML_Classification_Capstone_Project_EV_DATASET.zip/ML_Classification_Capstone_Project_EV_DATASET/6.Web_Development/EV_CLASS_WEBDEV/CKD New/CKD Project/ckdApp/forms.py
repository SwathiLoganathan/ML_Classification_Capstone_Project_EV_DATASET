from django import forms
from .models import *


class ckdForm(forms.ModelForm):
    class Meta():
        model=ckdModel
        fields=['Charging_Duration_minutes', 'Initial_Battery_Level',
       'Battery_Capacity_kWh', 'Maximum_Range_km', 'Charging_Station_ID']
